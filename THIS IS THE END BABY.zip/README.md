# GREATNESS — THIS IS THE END BABY (v15 Final Edition)

## Build APK on GitHub
1. Upload `THIS IS THE END BABY.zip` directly to your GitHub repo root.
2. Update `.github/workflows/build-apk.yml` so it unpacks `THIS IS THE END BABY.zip`.
3. Wait ~2–3 minutes in **Actions**, download `app-debug.apk` from **Artifacts**, and install.
