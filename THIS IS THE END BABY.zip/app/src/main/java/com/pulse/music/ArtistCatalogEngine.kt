package com.pulse.music

import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object ArtistCatalogEngine {
    private const val MAX_CACHE = 40
    private val cacheLock = Any()

    private val artistCache = object : LinkedHashMap<String, String>(20, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_CACHE
        }
    }

    private val albumCache = object : LinkedHashMap<Long, String>(20, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, String>?): Boolean {
            return size > MAX_CACHE
        }
    }

    private val FEAT_SPLIT_REGEX = Regex("\\s+(?:ft\\.?|feat\\.?|featuring|with|x|&)\\s+.*$", RegexOption.IGNORE_CASE)
    private val TOPIC_SUFFIX_REGEX = Regex("\\s*-\\s*Topic$|\\s*VEVO$|\\s*Official$", RegexOption.IGNORE_CASE)
    private val ART_SIZE_REGEX = Regex("\\d+x\\d+bb", RegexOption.IGNORE_CASE)

    fun clearCache(): Int {
        return synchronized(cacheLock) {
            val n = artistCache.size + albumCache.size
            artistCache.clear()
            albumCache.clear()
            n
        }
    }

    fun cleanArtistQuery(raw: String): String {
        var s = raw.trim()
        s = TOPIC_SUFFIX_REGEX.replace(s, "").trim()
        if (s.contains(",")) {
            s = s.substringBefore(",").trim()
        }
        s = FEAT_SPLIT_REGEX.replace(s, "").trim()
        return if (s.isNotBlank()) s else raw.trim()
    }

    private fun hdItunesArt(rawUrl: String?, size: Int = 1200): String {
        val clean = rawUrl?.trim().orEmpty()
        if (clean.isBlank()) return ""
        return if (ART_SIZE_REGEX.containsMatchIn(clean)) {
            ART_SIZE_REGEX.replace(clean, "${size}x${size}bb")
        } else {
            clean.replace("100x100", "${size}x${size}")
        }
    }

    private fun parseIsoToMillis(iso: String?): Long {
        if (iso.isNullOrBlank()) return 0L
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            sdf.parse(iso)?.time ?: 0L
        } catch (_: Exception) {
            val y = parseYear(iso)
            if (y > 1900) (y - 1970).toLong() * 31557600000L else 0L
        }
    }

    private fun parseYear(iso: String?): Int {
        if (iso.isNullOrBlank() || iso.length < 4) return 0
        return iso.substring(0, 4).toIntOrNull() ?: 0
    }

    private fun fetchJson(url: String): JSONObject? {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "GREATNESS-Android/14.0")
            .build()
        return PulseDownloader.httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string().orEmpty()
            if (body.isBlank()) null else JSONObject(body)
        }
    }

    fun searchArtists(query: String): String {
        val clean = query.trim()
        if (clean.isBlank()) return "[]"
        val enc = URLEncoder.encode(clean, "UTF-8")

        val artistsMap = LinkedHashMap<Long, JSONObject>()

        // 1. Official music artists match
        try {
            val root = fetchJson("https://itunes.apple.com/search?term=$enc&media=music&entity=musicArtist&limit=18")
            val results = root?.optJSONArray("results") ?: JSONArray()
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val id = item.optLong("artistId", 0L)
                val name = item.optString("artistName", "").trim()
                if (id > 0L && name.isNotBlank() && !artistsMap.containsKey(id)) {
                    artistsMap[id] = JSONObject().apply {
                        put("artistId", id)
                        put("name", name)
                        put("genre", item.optString("primaryGenreName", "Artist"))
                        put("cover", "")
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 2. Fetch albums for the same query to attach HD 600x600/1200x1200 artwork & catch artists
        try {
            val root = fetchJson("https://itunes.apple.com/search?term=$enc&media=music&entity=album&limit=40")
            val results = root?.optJSONArray("results") ?: JSONArray()
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val id = item.optLong("artistId", 0L)
                val name = item.optString("artistName", "").trim()
                val art = hdItunesArt(item.optString("artworkUrl100", ""), 600)
                if (id <= 0L || name.isBlank()) continue
                val existing = artistsMap[id]
                if (existing != null) {
                    if (existing.optString("cover").isBlank() && art.isNotBlank()) {
                        existing.put("cover", art)
                    }
                } else if (artistsMap.size < 20) {
                    artistsMap[id] = JSONObject().apply {
                        put("artistId", id)
                        put("name", name)
                        put("genre", item.optString("primaryGenreName", "Artist"))
                        put("cover", art)
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 3. Fallback to YouTube Music artist names if iTunes returned empty
        if (artistsMap.isEmpty()) {
            try {
                val tracks = JSONArray(YouTubeEngine.searchYouTubeStateless(clean, true))
                val seenNames = HashSet<String>()
                val out = JSONArray()
                for (i in 0 until tracks.length()) {
                    val t = tracks.optJSONObject(i) ?: continue
                    val aName = cleanArtistQuery(t.optString("artist", ""))
                    if (aName.isNotBlank() && seenNames.add(aName.lowercase())) {
                        out.put(JSONObject().apply {
                            put("artistId", 0L)
                            put("name", aName)
                            put("genre", "YouTube Music")
                            put("cover", t.optString("cover", ""))
                        })
                    }
                }
                return out.toString()
            } catch (_: Exception) {
                return "[]"
            }
        }

        val out = JSONArray()
        // Prioritize entries that have artwork
        val ordered = artistsMap.values.sortedByDescending { if (it.optString("cover").isNotBlank()) 1 else 0 }
        ordered.take(20).forEach { out.put(it) }
        return out.toString()
    }

    fun getArtistProfile(rawArtistName: String, rawArtistId: Long): String {
        val cleanName = cleanArtistQuery(rawArtistName)
        val cacheKey = if (rawArtistId > 0L) "id:$rawArtistId" else "name:${cleanName.lowercase()}"
        synchronized(cacheLock) {
            artistCache[cacheKey]?.let { return it }
        }

        var artistId = rawArtistId
        var resolvedName = cleanName
        var genre = "Artist"

        if (artistId <= 0L && cleanName.isNotBlank()) {
            try {
                val enc = URLEncoder.encode(cleanName, "UTF-8")
                val search = fetchJson("https://itunes.apple.com/search?term=$enc&media=music&entity=musicArtist&limit=10")
                val arr = search?.optJSONArray("results") ?: JSONArray()
                var bestObj: JSONObject? = null
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val nm = item.optString("artistName", "")
                    if (nm.equals(cleanName, ignoreCase = true)) {
                        bestObj = item
                        break
                    }
                    if (bestObj == null) bestObj = item
                }
                if (bestObj != null) {
                    artistId = bestObj.optLong("artistId", 0L)
                    resolvedName = bestObj.optString("artistName", cleanName).ifBlank { cleanName }
                    genre = bestObj.optString("primaryGenreName", "Artist").ifBlank { "Artist" }
                }
            } catch (_: Exception) {
            }
        }

        if (artistId > 0L) {
            try {
                val profileJson = fetchItunesArtistProfile(artistId, resolvedName, genre)
                if (profileJson != null) {
                    synchronized(cacheLock) {
                        artistCache[cacheKey] = profileJson
                        artistCache["id:$artistId"] = profileJson
                    }
                    return profileJson
                }
            } catch (_: Exception) {
            }
        }

        // Fallback: YouTube Music tracks for indie / non-iTunes artists
        val ytFallback = buildYouTubeFallbackArtist(cleanName)
        synchronized(cacheLock) {
            artistCache[cacheKey] = ytFallback
        }
        return ytFallback
    }

    private fun fetchItunesArtistProfile(artistId: Long, fallbackName: String, fallbackGenre: String): String? {
        val songsRoot = fetchJson("https://itunes.apple.com/lookup?id=$artistId&entity=song&limit=25")
        val albumsRoot = fetchJson("https://itunes.apple.com/lookup?id=$artistId&entity=album&limit=120")

        var name = fallbackName
        var genre = fallbackGenre
        val topSongs = JSONArray()
        val seenSongs = HashSet<String>()
        val popularCollectionBoost = HashMap<Long, Int>()

        val songResults = songsRoot?.optJSONArray("results") ?: JSONArray()
        var rankBoost = 100
        for (i in 0 until songResults.length()) {
            val item = songResults.optJSONObject(i) ?: continue
            val wrapper = item.optString("wrapperType")
            if (wrapper == "artist") {
                name = item.optString("artistName", name).ifBlank { name }
                genre = item.optString("primaryGenreName", genre).ifBlank { genre }
                continue
            }
            if (wrapper != "track") continue
            val trackId = item.optLong("trackId", 0L)
            val title = item.optString("trackName", "").trim()
            if (trackId <= 0L || title.isBlank()) continue
            val dedupKey = title.lowercase()
            if (!seenSongs.add(dedupKey)) continue

            val collId = item.optLong("collectionId", 0L)
            if (collId > 0L && !popularCollectionBoost.containsKey(collId)) {
                popularCollectionBoost[collId] = rankBoost
                rankBoost = (rankBoost - 4).coerceAtLeast(10)
            }

            val hdCover = hdItunesArt(item.optString("artworkUrl100", ""), 1200)
            topSongs.put(JSONObject().apply {
                put("id", "itunes_$trackId")
                put("title", title)
                put("artist", item.optString("artistName", name))
                put("album", item.optString("collectionName", ""))
                put("duration", (item.optLong("trackTimeMillis", 0L).coerceAtLeast(0L)) / 1000.0)
                put("cover", hdCover)
                put("source", "catalog")
            })
        }

        val albumsList = ArrayList<JSONObject>()
        val seenReleases = HashMap<String, JSONObject>()
        val albumResults = albumsRoot?.optJSONArray("results") ?: JSONArray()

        for (i in 0 until albumResults.length()) {
            val item = albumResults.optJSONObject(i) ?: continue
            val wrapper = item.optString("wrapperType")
            if (wrapper == "artist") {
                name = item.optString("artistName", name).ifBlank { name }
                genre = item.optString("primaryGenreName", genre).ifBlank { genre }
                continue
            }
            if (wrapper != "collection") continue
            val collId = item.optLong("collectionId", 0L)
            val rawTitle = item.optString("collectionName", "").trim()
            if (collId <= 0L || rawTitle.isBlank()) continue

            val trackCount = item.optInt("trackCount", 1)
            val isoDate = item.optString("releaseDate", "")
            val year = parseYear(isoDate)
            val releaseTs = parseIsoToMillis(isoDate)

            val lowerTitle = rawTitle.lowercase()
            val releaseType = when {
                lowerTitle.endsWith(" - single") || trackCount <= 3 -> "single"
                lowerTitle.endsWith(" - ep") || trackCount in 4..6 -> "ep"
                else -> "album"
            }

            val cleanTitle = rawTitle
                .replace(Regex("\\s*-\\s*Single$", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s*-\\s*EP$", RegexOption.IGNORE_CASE), "")
                .trim()
                .ifBlank { rawTitle }

            val hdCover = hdItunesArt(item.optString("artworkUrl100", ""), 1200)
            val gridCover = hdItunesArt(item.optString("artworkUrl100", ""), 600)
            val boost = popularCollectionBoost[collId] ?: 0
            // Base popularity score combines hit-song boost + iTunes default catalog order
            val popScore = boost * 1000 + (500 - i.coerceAtMost(499)) + (if (releaseType == "album") 120 else 0)

            val entry = JSONObject().apply {
                put("collectionId", collId)
                put("title", cleanTitle)
                put("artist", item.optString("artistName", name))
                put("cover", hdCover)
                put("coverThumb", gridCover)
                put("releaseDate", isoDate)
                put("year", year)
                put("releaseTs", releaseTs)
                put("trackCount", trackCount)
                put("releaseType", releaseType)
                put("popScore", popScore)
                put("genre", item.optString("primaryGenreName", genre))
            }

            // Merge clean vs explicit duplicates with identical title & year (keep explicit or higher trackCount)
            val dedupKey = "${cleanTitle.lowercase()}|$year|$releaseType"
            val prev = seenReleases[dedupKey]
            val isExplicit = item.optString("collectionExplicitness", "") == "explicit"
            if (prev == null || (isExplicit && !prev.optBoolean("_explicit", false)) || trackCount > prev.optInt("trackCount", 0)) {
                entry.put("_explicit", isExplicit)
                seenReleases[dedupKey] = entry
            }
        }

        seenReleases.values.forEach {
            it.remove("_explicit")
            albumsList.add(it)
        }

        albumsList.sortByDescending { it.optInt("popScore", 0) }

        val releasesArr = JSONArray()
        albumsList.forEach { releasesArr.put(it) }

        if (topSongs.length() == 0 && releasesArr.length() == 0) return null

        val heroCover = when {
            topSongs.length() > 0 && topSongs.getJSONObject(0).optString("cover").isNotBlank() ->
                topSongs.getJSONObject(0).optString("cover")
            releasesArr.length() > 0 ->
                releasesArr.getJSONObject(0).optString("cover")
            else -> ""
        }

        return JSONObject().apply {
            put("artistId", artistId)
            put("name", name)
            put("genre", genre)
            put("cover", heroCover)
            put("topSongs", topSongs)
            put("releases", releasesArr)
            put("source", "itunes")
        }.toString()
    }

    private fun buildYouTubeFallbackArtist(artistName: String): String {
        val topSongs = JSONArray()
        var heroCover = ""
        try {
            val tracks = JSONArray(YouTubeEngine.searchYouTubeStateless(artistName, true))
            for (i in 0 until tracks.length().coerceAtMost(20)) {
                val t = tracks.optJSONObject(i) ?: continue
                if (heroCover.isBlank()) heroCover = t.optString("cover", "")
                topSongs.put(t)
            }
        } catch (_: Exception) {
        }
        return JSONObject().apply {
            put("artistId", 0L)
            put("name", artistName.ifBlank { "Artist" })
            put("genre", "YouTube Music")
            put("cover", heroCover)
            put("topSongs", topSongs)
            put("releases", JSONArray())
            put("source", "youtube")
        }.toString()
    }

    fun getAlbumTracks(collectionId: Long): String {
        if (collectionId <= 0L) throw IllegalArgumentException("Invalid album ID")
        synchronized(cacheLock) {
            albumCache[collectionId]?.let { return it }
        }

        val root = fetchJson("https://itunes.apple.com/lookup?id=$collectionId&entity=song&limit=100")
            ?: throw IllegalStateException("Could not load album")
        val results = root.optJSONArray("results") ?: JSONArray()

        var title = "Album"
        var artist = "Artist"
        var artistId = 0L
        var cover = ""
        var year = 0
        var releaseType = "album"
        var genre = ""
        val tracks = ArrayList<JSONObject>()

        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val wrapper = item.optString("wrapperType")
            if (wrapper == "collection") {
                val rawTitle = item.optString("collectionName", "Album")
                title = rawTitle
                    .replace(Regex("\\s*-\\s*Single$", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s*-\\s*EP$", RegexOption.IGNORE_CASE), "")
                    .trim()
                    .ifBlank { rawTitle }
                artist = item.optString("artistName", "Artist")
                artistId = item.optLong("artistId", 0L)
                cover = hdItunesArt(item.optString("artworkUrl100", ""), 1200)
                year = parseYear(item.optString("releaseDate", ""))
                genre = item.optString("primaryGenreName", "")
                val tc = item.optInt("trackCount", 1)
                val lt = rawTitle.lowercase()
                releaseType = when {
                    lt.endsWith(" - single") || tc <= 3 -> "single"
                    lt.endsWith(" - ep") || tc in 4..6 -> "ep"
                    else -> "album"
                }
            } else if (wrapper == "track") {
                val tid = item.optLong("trackId", 0L)
                val tTitle = item.optString("trackName", "").trim()
                if (tid <= 0L || tTitle.isBlank()) continue
                val tCover = hdItunesArt(item.optString("artworkUrl100", ""), 1200).ifBlank { cover }
                tracks.add(JSONObject().apply {
                    put("id", "itunes_$tid")
                    put("title", tTitle)
                    put("artist", item.optString("artistName", artist))
                    put("album", title)
                    put("discNumber", item.optInt("discNumber", 1))
                    put("trackNumber", item.optInt("trackNumber", tracks.size + 1))
                    put("duration", (item.optLong("trackTimeMillis", 0L).coerceAtLeast(0L)) / 1000.0)
                    put("cover", tCover)
                    put("source", "catalog")
                })
            }
        }

        tracks.sortWith(compareBy({ it.optInt("discNumber", 1) }, { it.optInt("trackNumber", 0) }))
        val tracksArr = JSONArray()
        tracks.forEach { tracksArr.put(it) }

        val out = JSONObject().apply {
            put("collectionId", collectionId)
            put("title", title)
            put("artist", artist)
            put("artistId", artistId)
            put("cover", cover)
            put("year", year)
            put("releaseType", releaseType)
            put("genre", genre)
            put("tracks", tracksArr)
        }.toString()

        synchronized(cacheLock) {
            albumCache[collectionId] = out
        }
        return out
    }
}
