package com.pulse.music

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "PulseMain"
    }

    private lateinit var rootContainer: FrameLayout
    private lateinit var webView: WebView
    private var lastSafeTopDp: Float = 0f
    private var lastSafeRightDp: Float = 0f
    private var lastSafeBottomDp: Float = 0f
    private var lastSafeLeftDp: Float = 0f
    private var pageReady: Boolean = false

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val tickerHandler = Handler(Looper.getMainLooper())

    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private var isForeground: Boolean = false
    private var activePlayJob: Job? = null
    private var activeThemeJob: Job? = null
    private var activeSearchJob: Job? = null
    private var activeImportJob: Job? = null
    private var activeArtistJob: Job? = null
    private var activeAlbumJob: Job? = null
    private var activeFadeJob: Job? = null
    private var activeWidgetArtJob: Job? = null
    private val activeDownloads = ConcurrentHashMap.newKeySet<String>()

    private var activeTrackMeta: JSONObject? = null
    private var currentCandidates: List<YouTubeEngine.StreamCandidate> = emptyList()
    private var candidateIndex: Int = 0
    private var retriedFreshExtraction: Boolean = false
    private var pendingResumePosMs: Long = 0L

    private var pendingBackupJson: String? = null
    private var pendingSharedText: String? = null
    private var pendingSpinRoulette: Boolean = false

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val audioPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            performLocalAudioScan()
        } else {
            emitJs("window.__pulseOnError && window.__pulseOnError('Audio permission needed to scan local files')")
        }
    }

    private val exportBackupLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val payload = pendingBackupJson
        pendingBackupJson = null
        if (uri == null || payload == null) return@registerForActivityResult
        uiScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                emitJs("window.__pulseOnBackupExported && window.__pulseOnBackupExported(true, 'Backup saved!')")
            } catch (e: Exception) {
                emitJs("window.__pulseOnBackupExported && window.__pulseOnBackupExported(false, ${safeJsonString(e.message ?: "Export failed")})")
            }
        }
    }

    private val importBackupLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        uiScope.launch(Dispatchers.IO) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("Empty backup file")
                JSONObject(text)
                emitJs("window.__pulseOnBackupLoaded && window.__pulseOnBackupLoaded(${safeJsonString(text)})")
            } catch (e: Exception) {
                emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString("Invalid backup: " + (e.message ?: "parse error"))})")
            }
        }
    }

    private fun pushPlaybackState(snap: Boolean = false) {
        val ctrl = mediaController ?: return
        val posSec = ctrl.currentPosition.coerceAtLeast(0L) / 1000.0
        val durSec = (ctrl.duration.takeIf { it > 0 } ?: 0L) / 1000.0
        val playing = ctrl.isPlaying
        emitJs("window.__pulseOnProgress && window.__pulseOnProgress($posSec, $durSec, $playing, $snap)")
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            val ctrl = mediaController
            if (isForeground && ctrl != null && ctrl.isPlaying) {
                pushPlaybackState(snap = false)
                tickerHandler.postDelayed(this, 200L)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    pageReady = true
                    pushSafeAreaToWeb()
                    ViewCompat.requestApplyInsets(rootContainer)
                    flushPendingIntentActions()
                }
            }
            addJavascriptInterface(PulseJsBridge(), "PulseNative")
        }

        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(
                webView,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        val safeTypes = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        ViewCompat.setOnApplyWindowInsetsListener(rootContainer) { view, windowInsets ->
            val safe = windowInsets.getInsets(safeTypes)
            val ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime())
            val density = resources.displayMetrics.density.coerceAtLeast(1f)

            lastSafeTopDp = safe.top / density
            lastSafeRightDp = safe.right / density
            lastSafeBottomDp = safe.bottom / density
            lastSafeLeftDp = safe.left / density

            val imeExtraBottom = (ime.bottom - safe.bottom).coerceAtLeast(0)
            view.setPadding(0, 0, 0, imeExtraBottom)

            pushSafeAreaToWeb()

            WindowInsetsCompat.Builder(windowInsets)
                .setInsets(safeTypes, Insets.NONE)
                .setInsets(WindowInsetsCompat.Type.ime(), Insets.NONE)
                .build()
        }

        setContentView(rootContainer)
        ViewCompat.requestApplyInsets(rootContainer)
        webView.loadUrl("file:///android_asset/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(window.__pulseHandleBack && window.__pulseHandleBack()) ? 'handled' : 'exit'"
                ) { result ->
                    if (result == null || !result.contains("handled")) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        PlaybackSkipBus.onSkipNext = {
            emitJs("window.__pulseSkipNext && window.__pulseSkipNext()")
        }
        PlaybackSkipBus.onSkipPrev = {
            emitJs("window.__pulseSkipPrev && window.__pulseSkipPrev()")
        }
        PlaybackSkipBus.onTogglePlay = {
            runOnUiThread {
                val ctrl = mediaController
                if (ctrl != null) {
                    togglePlaybackWithOptionalFade(ctrl)
                } else {
                    emitJs("window.__pulseWidgetTogglePlay && window.__pulseWidgetTogglePlay()")
                }
            }
        }

        handleIncomingIntent(intent)
        connectMediaService()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra(GreatnessWidgetProvider.EXTRA_SPIN_ROULETTE, false) ||
            intent.action == GreatnessWidgetProvider.ACTION_ROULETTE
        ) {
            intent.removeExtra(GreatnessWidgetProvider.EXTRA_SPIN_ROULETTE)
            pendingSpinRoulette = true
            if (pageReady) flushPendingIntentActions()
            return
        }
        if (intent.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val shared = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
            if (!shared.isNullOrBlank()) {
                pendingSharedText = shared
                if (pageReady) flushPendingIntentActions()
            }
        }
    }

    private fun flushPendingIntentActions() {
        if (!pageReady) return
        if (pendingSpinRoulette) {
            pendingSpinRoulette = false
            emitJs("window.__pulseTriggerRoulette && window.__pulseTriggerRoulette()")
        }
        val shared = pendingSharedText
        if (!shared.isNullOrBlank()) {
            pendingSharedText = null
            emitJs("window.__pulseOnStatus && window.__pulseOnStatus('Reading shared YouTube link...')")
            uiScope.launch(Dispatchers.IO) {
                try {
                    val resolvedJson = YouTubeEngine.resolveSharedInput(shared)
                    emitJs("window.__pulseOnSharedContent && window.__pulseOnSharedContent($resolvedJson)")
                } catch (e: Exception) {
                    emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString(e.message ?: "Could not open shared link")})")
                }
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val res = super.dispatchKeyEvent(event)
        if (event.action == KeyEvent.ACTION_DOWN &&
            (code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)
        ) {
            tickerHandler.postDelayed({
                val pct = readCurrentVolumePercent()
                emitJs("window.__pulseOnVolumeChanged && window.__pulseOnVolumeChanged($pct)")
            }, 60L)
        }
        return res
    }

    private fun readCurrentVolumePercent(): Int {
        return try {
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, maxVol)
            ((curVol * 100f) / maxVol).roundToInt()
        } catch (_: Exception) {
            70
        }
    }

    override fun onStart() {
        super.onStart()
        isForeground = true
        pushPlaybackState(snap = true)
        tickerHandler.removeCallbacks(progressTicker)
        if (mediaController?.isPlaying == true) {
            tickerHandler.post(progressTicker)
        }
    }

    override fun onStop() {
        isForeground = false
        tickerHandler.removeCallbacks(progressTicker)
        super.onStop()
    }

    private fun connectMediaService() {
        val token = SessionToken(this, ComponentName(this, PulsePlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                val ctrl = controllerFuture?.get() ?: return@addListener
                mediaController = ctrl
                ctrl.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        pushPlaybackState(snap = true)
                        tickerHandler.removeCallbacks(progressTicker)
                        if (isForeground && isPlaying) tickerHandler.post(progressTicker)
                        val tObj = activeTrackMeta
                        if (tObj != null) {
                            GreatnessWidgetProvider.updateAllWidgets(
                                context = this@MainActivity,
                                title = tObj.optString("title", "GREATNESS"),
                                artist = tObj.optString("artist", ""),
                                isPlaying = isPlaying
                            )
                        }
                    }

                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo,
                        newPosition: Player.PositionInfo,
                        reason: Int
                    ) {
                        pushPlaybackState(snap = true)
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            pushPlaybackState(snap = true)
                        } else if (playbackState == Player.STATE_ENDED) {
                            emitJs("window.__pulseOnEnded && window.__pulseOnEnded()")
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        Log.w(TAG, "ExoPlayer error (${error.errorCodeName}): ${error.message}")
                        val savedPos = ctrl.currentPosition.coerceAtLeast(0L)
                        if (savedPos > 2000L) pendingResumePosMs = savedPos
                        tryNextCandidateOrReExtract(error.message ?: error.errorCodeName)
                    }
                })
                if (isForeground) pushPlaybackState(snap = true)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to connect MediaController", e)
                emitJs("window.__pulseOnError && window.__pulseOnError('Audio service unavailable')")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun togglePlaybackWithOptionalFade(ctrl: MediaController) {
        activeFadeJob?.cancel()
        if (ctrl.isPlaying) {
            if (AudioFxBus.fadeEnabled) {
                activeFadeJob = uiScope.launch {
                    val steps = 8
                    for (i in steps downTo 1) {
                        AudioFxBus.setVolumeDirect(i.toFloat() / steps)
                        delay(28L)
                    }
                    ctrl.pause()
                    AudioFxBus.setVolumeDirect(1.0f)
                }
            } else {
                AudioFxBus.setVolumeDirect(1.0f)
                ctrl.pause()
            }
        } else {
            if (AudioFxBus.fadeEnabled) {
                AudioFxBus.setVolumeDirect(0.05f)
                ctrl.play()
                activeFadeJob = uiScope.launch {
                    val steps = 10
                    for (i in 1..steps) {
                        AudioFxBus.setVolumeDirect(i.toFloat() / steps)
                        delay(28L)
                    }
                }
            } else {
                AudioFxBus.setVolumeDirect(1.0f)
                ctrl.play()
            }
        }
    }

    private fun tryNextCandidateOrReExtract(reason: String) {
        val nextIdx = candidateIndex + 1
        if (nextIdx < currentCandidates.size) {
            candidateIndex = nextIdx
            val next = currentCandidates[candidateIndex]
            emitJs("window.__pulseOnStatus && window.__pulseOnStatus(${safeJsonString("Switching stream -> ${next.label}")})")
            playCurrentCandidate()
            return
        }

        val trackObj = activeTrackMeta
        val isLocal = trackObj?.optString("localUri", "").orEmpty().isNotBlank()
        if (!isLocal && !retriedFreshExtraction && trackObj != null) {
            retriedFreshExtraction = true
            emitJs("window.__pulseOnStatus && window.__pulseOnStatus('Refreshing stream...')")
            startTrackPlayback(trackObj, forceRefresh = true, resumeMs = pendingResumePosMs)
            return
        }

        pendingResumePosMs = 0L
        emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString("Playback error: $reason")})")
    }

    private fun extractCoverThemeAsync(trackId: String, coverUrl: String) {
        activeThemeJob?.cancel()
        if (!coverUrl.startsWith("http://") && !coverUrl.startsWith("https://")) return
        activeThemeJob = uiScope.launch(Dispatchers.IO) {
            val themeJson = CoverThemeExtractor.extractThemeJson(coverUrl)
            emitJs("window.__pulseOnCoverTheme && window.__pulseOnCoverTheme(${safeJsonString(trackId)}, $themeJson)")
        }
    }

    private fun updateWidgetArtworkAsync(title: String, artist: String, coverUrl: String) {
        activeWidgetArtJob?.cancel()
        GreatnessWidgetProvider.updateAllWidgets(
            context = this,
            title = title,
            artist = artist,
            isPlaying = true
        )
        if (!coverUrl.startsWith("http://") && !coverUrl.startsWith("https://")) return
        activeWidgetArtJob = uiScope.launch(Dispatchers.IO) {
            try {
                val compactUrl = when {
                    coverUrl.contains("mzstatic.com", ignoreCase = true) ->
                        coverUrl.replace(Regex("\\d+x\\d+bb", RegexOption.IGNORE_CASE), "240x240bb")
                    YouTubeEngine.isSquareMusicArt(coverUrl) ->
                        coverUrl.replace(Regex("=[ws]\\d+[^&?]*$"), "=w240-h240-l85-rj")
                    coverUrl.contains("ytimg.com", ignoreCase = true) ->
                        coverUrl.replace("maxresdefault.jpg", "hqdefault.jpg", ignoreCase = true)
                    else -> coverUrl
                }
                val req = Request.Builder()
                    .url(compactUrl)
                    .header("User-Agent", PulseDownloader.USER_AGENT)
                    .build()
                val bytes = PulseDownloader.httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) resp.body?.bytes() else null
                } ?: return@launch
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@launch
                val scaled = Bitmap.createScaledBitmap(bmp, 144, 144, true)
                if (scaled != bmp) bmp.recycle()
                GreatnessWidgetProvider.updateAllWidgets(
                    context = this@MainActivity,
                    title = title,
                    artist = artist,
                    isPlaying = mediaController?.isPlaying ?: true,
                    artwork = scaled
                )
            } catch (_: Exception) {
            }
        }
    }

    private fun startTrackPlayback(trackObj: JSONObject, forceRefresh: Boolean, resumeMs: Long = 0L) {
        activePlayJob?.cancel()
        activeFadeJob?.cancel()
        activeTrackMeta = trackObj
        pendingResumePosMs = resumeMs
        if (!forceRefresh) retriedFreshExtraction = false

        val rawId = trackObj.getString("id")
        val title = trackObj.optString("title", "Unknown")
        val artist = trackObj.optString("artist", "YouTube")
        val cover = trackObj.optString("cover", "")
        val localUri = trackObj.optString("localUri", "")

        extractCoverThemeAsync(rawId, cover)
        updateWidgetArtworkAsync(title, artist, cover)

        activePlayJob = uiScope.launch(Dispatchers.IO) {
            try {
                emitJs("window.__pulseOnStatus && window.__pulseOnStatus('Loading audio stream...')")

                var waitMs = 0
                while (mediaController == null && waitMs < 4000) {
                    delay(100)
                    waitMs += 100
                }
                if (mediaController == null) {
                    throw IllegalStateException("Audio service did not start in time")
                }

                if (localUri.isNotBlank()) {
                    launch(Dispatchers.Main) {
                        currentCandidates = listOf(
                            YouTubeEngine.StreamCandidate(
                                url = localUri,
                                label = "Local File",
                                ext = "local",
                                bitrateKbps = 320
                            )
                        )
                        candidateIndex = 0
                        playCurrentCandidate()
                        val statusJson = YouTubeEngine.getStatusJson()
                        emitJs("window.__pulseOnTrackReady && window.__pulseOnTrackReady($statusJson, 'Playing local audio')")
                    }
                    return@launch
                }

                // Check offline Opus save first for catalog tracks (works 100% offline with zero network!)
                val offlineCatalogFile = if (rawId.startsWith("itunes_")) {
                    YouTubeEngine.findOfflineFileByOrigId(this@MainActivity, rawId)
                } else {
                    null
                }
                val streamId = if (offlineCatalogFile != null) {
                    rawId
                } else if (rawId.startsWith("itunes_")) {
                    val ytId = YouTubeEngine.resolveYouTubeIdForCatalogTrack(rawId, title, artist)
                    emitJs("window.__pulseOnCatalogResolved && window.__pulseOnCatalogResolved(${safeJsonString(rawId)}, ${safeJsonString(ytId)})")
                    ytId
                } else {
                    rawId
                }

                val resolved = YouTubeEngine.resolvePlayback(
                    context = this@MainActivity,
                    videoIdOrUrl = streamId,
                    forceRefresh = forceRefresh
                )

                launch(Dispatchers.Main) {
                    currentCandidates = resolved.candidates
                    candidateIndex = 0
                    playCurrentCandidate()
                    val statusJson = YouTubeEngine.getStatusJson()
                    val note = when {
                        resolved.isOffline -> "Playing offline"
                        resolved.healed -> "Refreshed YouTube auth"
                        else -> ""
                    }
                    emitJs("window.__pulseOnTrackReady && window.__pulseOnTrackReady($statusJson, ${safeJsonString(note)})")
                }
            } catch (_: CancellationException) {
            } catch (e: Exception) {
                Log.e(TAG, "Playback resolution failed", e)
                emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString(e.message ?: "Could not load track")})")
            }
        }
    }

    private fun playCurrentCandidate() {
        val ctrl = mediaController ?: return
        val trackObj = activeTrackMeta ?: return
        val cand = currentCandidates.getOrNull(candidateIndex) ?: return

        val id = trackObj.optString("id", "")
        val title = trackObj.optString("title", "Unknown")
        val artist = trackObj.optString("artist", "YouTube")
        val cover = YouTubeEngine.upgradeCoverUrl(trackObj.optString("cover", ""), id, 1200)

        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setArtworkUri(if (cover.isNotBlank()) Uri.parse(cover) else null)
            .build()

        val builder = MediaItem.Builder()
            .setUri(cand.url)
            .setMediaMetadata(metadata)

        if (cand.isHls) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        }

        val startAt = pendingResumePosMs
        pendingResumePosMs = 0L

        activeFadeJob?.cancel()
        if (AudioFxBus.fadeEnabled) {
            AudioFxBus.setVolumeDirect(0.08f)
        } else {
            AudioFxBus.setVolumeDirect(1.0f)
        }

        ctrl.setMediaItem(builder.build(), startAt)
        ctrl.prepare()
        ctrl.play()

        if (AudioFxBus.fadeEnabled) {
            activeFadeJob = uiScope.launch {
                val steps = 12
                for (i in 1..steps) {
                    AudioFxBus.setVolumeDirect(i.toFloat() / steps)
                    delay(32L)
                }
            }
        }
    }

    private fun performLocalAudioScan() {
        uiScope.launch(Dispatchers.IO) {
            try {
                val out = JSONArray()
                val projection = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.ALBUM_ID
                )
                val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 15000"
                val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    null,
                    sortOrder
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                    val artBase = Uri.parse("content://media/external/audio/albumart")
                    var count = 0
                    while (cursor.moveToNext() && count < 400) {
                        val mediaId = cursor.getLong(idCol)
                        val contentUri = ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            mediaId
                        ).toString()
                        val albumId = cursor.getLong(albumCol)
                        val artUri = if (albumId > 0L) {
                            ContentUris.withAppendedId(artBase, albumId).toString()
                        } else {
                            ""
                        }
                        val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Audio Track"
                        val rawArtist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Local Audio"
                        val durSec = (cursor.getLong(durCol).coerceAtLeast(0L)) / 1000.0

                        out.put(JSONObject().apply {
                            put("id", "local_$mediaId")
                            put("title", title)
                            put("artist", rawArtist)
                            put("duration", durSec)
                            put("cover", artUri)
                            put("localUri", contentUri)
                            put("source", "local")
                        })
                        count++
                    }
                }
                emitJs("window.__pulseOnLocalTracks && window.__pulseOnLocalTracks($out)")
            } catch (e: Exception) {
                emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString("Scan failed: " + (e.message ?: "error"))})")
            }
        }
    }

    private fun pushSafeAreaToWeb() {
        val t = String.format(Locale.US, "%.2f", lastSafeTopDp)
        val r = String.format(Locale.US, "%.2f", lastSafeRightDp)
        val b = String.format(Locale.US, "%.2f", lastSafeBottomDp)
        val l = String.format(Locale.US, "%.2f", lastSafeLeftDp)
        emitJs("window.__pulseOnSafeArea && window.__pulseOnSafeArea($t,$r,$b,$l)")
    }

    private fun emitJs(script: String) {
        runOnUiThread {
            if (!isDestroyed && !isFinishing) {
                webView.evaluateJavascript(script, null)
            }
        }
    }

    private fun safeJsonString(value: String): String = JSONObject.quote(value)

    inner class PulseJsBridge {

        @JavascriptInterface
        fun getVolumePercent(): Int = readCurrentVolumePercent()

        @JavascriptInterface
        fun stepVolume(delta: Int): Int {
            return try {
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val step = max(1, (maxVol / 20f).roundToInt())
                val nextVol = (curVol + delta * step).coerceIn(0, maxVol)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                ((nextVol * 100f) / maxVol).roundToInt()
            } catch (_: Exception) {
                70
            }
        }

        @JavascriptInterface
        fun haptic(style: String) {
            try {
                val vib = vibrator ?: return
                if (!vib.hasVibrator()) return

                val durationMs = when (style) {
                    "click" -> 22L
                    "tick" -> 10L
                    else -> 7L
                }
                val amplitude = when (style) {
                    "click" -> 225
                    "tick" -> 145
                    else -> 105
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val amp = if (vib.hasAmplitudeControl()) amplitude else VibrationEffect.DEFAULT_AMPLITUDE
                    vib.vibrate(VibrationEffect.createOneShot(durationMs, amp))
                } else {
                    @Suppress("DEPRECATION")
                    vib.vibrate(durationMs)
                }
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun setSystemTheme(bgHex: String, isLight: Boolean) {
            runOnUiThread {
                try {
                    val color = Color.parseColor(bgHex)
                    window.decorView.setBackgroundColor(color)
                    rootContainer.setBackgroundColor(color)
                    webView.setBackgroundColor(color)
                    @Suppress("DEPRECATION")
                    window.statusBarColor = Color.TRANSPARENT
                    @Suppress("DEPRECATION")
                    window.navigationBarColor = Color.TRANSPARENT
                    val insetsCtrl = WindowCompat.getInsetsController(window, window.decorView)
                    insetsCtrl.isAppearanceLightStatusBars = isLight
                    insetsCtrl.isAppearanceLightNavigationBars = isLight
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setStatusBarLight(isLight: Boolean) {
            runOnUiThread {
                try {
                    val insetsCtrl = WindowCompat.getInsetsController(window, window.decorView)
                    insetsCtrl.isAppearanceLightStatusBars = isLight
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getAuthStatus(): String = YouTubeEngine.getStatusJson()

        @JavascriptInterface
        fun forceRefreshAuth() {
            uiScope.launch(Dispatchers.IO) {
                val msg = YouTubeEngine.resetExtractorCache()
                val statusJson = YouTubeEngine.getStatusJson()
                emitJs("window.__pulseOnAuthUpdated && window.__pulseOnAuthUpdated($statusJson, ${safeJsonString(msg)})")
            }
        }

        @JavascriptInterface
        fun clearAllCaches() {
            uiScope.launch(Dispatchers.IO) {
                val msg = YouTubeEngine.clearAllAppCaches(this@MainActivity)
                val statusJson = YouTubeEngine.getStatusJson()
                emitJs("window.__pulseOnAuthUpdated && window.__pulseOnAuthUpdated($statusJson, ${safeJsonString(msg)})")
            }
        }

        @JavascriptInterface
        fun importPlaylist(urlOrId: String, callbackId: String) {
            activeImportJob?.cancel()
            activeImportJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonStr = YouTubeEngine.importPlaylist(urlOrId)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonStr, null)")
                } catch (_: CancellationException) {
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Playlist import failed")})")
                }
            }
        }

        @JavascriptInterface
        fun searchArtists(query: String, callbackId: String) {
            activeSearchJob?.cancel()
            activeSearchJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val arrStr = ArtistCatalogEngine.searchArtists(query)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $arrStr, null)")
                } catch (_: CancellationException) {
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Artist search failed")})")
                }
            }
        }

        @JavascriptInterface
        fun getArtistProfile(artistName: String, artistId: Long, callbackId: String) {
            activeArtistJob?.cancel()
            activeArtistJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonStr = ArtistCatalogEngine.getArtistProfile(artistName, artistId)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonStr, null)")
                } catch (_: CancellationException) {
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Could not load artist")})")
                }
            }
        }

        @JavascriptInterface
        fun getAlbumTracks(collectionId: Long, callbackId: String) {
            activeAlbumJob?.cancel()
            activeAlbumJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonStr = ArtistCatalogEngine.getAlbumTracks(collectionId)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonStr, null)")
                } catch (_: CancellationException) {
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Could not load album")})")
                }
            }
        }

        @JavascriptInterface
        fun setAudioFx(preset: String, bassPercent: Int) {
            AudioFxBus.apply(preset, bassPercent)
        }

        @JavascriptInterface
        fun setAudioFxFull(
            preset: String,
            bassPercent: Int,
            loudnessPercent: Int,
            speed: Double,
            pitch: Double,
            skipSilence: Boolean
        ) {
            AudioFxBus.applyFull(
                preset = preset,
                bassPercent = bassPercent,
                loudnessPercent = loudnessPercent,
                speed = speed.toFloat(),
                pitch = pitch.toFloat(),
                skipSilence = skipSilence
            )
        }

        @JavascriptInterface
        fun setFadeEnabled(enabled: Boolean) {
            AudioFxBus.fadeEnabled = enabled
        }

        @JavascriptInterface
        fun setPlayerVolume(vol: Double) {
            AudioFxBus.setVolumeDirect(vol.toFloat())
        }

        @JavascriptInterface
        fun pauseNow() {
            runOnUiThread {
                activeFadeJob?.cancel()
                mediaController?.pause()
                AudioFxBus.setVolumeDirect(1.0f)
            }
        }

        @JavascriptInterface
        fun getAudioFx(): String = AudioFxBus.getStateJson()

        @JavascriptInterface
        fun searchPaged(query: String, musicOnly: Boolean, callbackId: String) {
            activeSearchJob?.cancel()
            activeSearchJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonObjStr = YouTubeEngine.searchYouTubePaged(query, musicOnly)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonObjStr, null)")
                } catch (_: CancellationException) {
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Search failed")})")
                }
            }
        }

        @JavascriptInterface
        fun searchMore(callbackId: String) {
            uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonObjStr = YouTubeEngine.searchYouTubeMore()
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonObjStr, null)")
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Could not load more")})")
                }
            }
        }

        @JavascriptInterface
        fun search(query: String, musicOnly: Boolean, callbackId: String) {
            activeSearchJob?.cancel()
            activeSearchJob = uiScope.launch(Dispatchers.IO) {
                try {
                    val jsonArrayStr = YouTubeEngine.searchYouTube(query, musicOnly)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $jsonArrayStr, null)")
                } catch (_: CancellationException) {
                } catch (e: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, null, ${safeJsonString(e.message ?: "Search failed")})")
                }
            }
        }

        @JavascriptInterface
        fun getRelatedTracks(videoId: String, callbackId: String) {
            uiScope.launch(Dispatchers.IO) {
                try {
                    val arrStr = YouTubeEngine.getRelatedTracksJson(videoId)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $arrStr, null)")
                } catch (_: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, [], null)")
                }
            }
        }

        @JavascriptInterface
        fun getSponsorSegments(videoId: String, callbackId: String) {
            uiScope.launch(Dispatchers.IO) {
                try {
                    val arrStr = YouTubeEngine.fetchSponsorSegmentsJson(videoId)
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, $arrStr, null)")
                } catch (_: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, [], null)")
                }
            }
        }

        @JavascriptInterface
        fun scanLocalMusic() {
            runOnUiThread {
                val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Manifest.permission.READ_MEDIA_AUDIO
                } else {
                    Manifest.permission.READ_EXTERNAL_STORAGE
                }
                if (ContextCompat.checkSelfPermission(this@MainActivity, perm) == PackageManager.PERMISSION_GRANTED) {
                    performLocalAudioScan()
                } else {
                    audioPermLauncher.launch(perm)
                }
            }
        }

        @JavascriptInterface
        fun exportBackup(jsonPayload: String) {
            runOnUiThread {
                pendingBackupJson = jsonPayload
                val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                exportBackupLauncher.launch("GREATNESS-backup-$stamp.json")
            }
        }

        @JavascriptInterface
        fun importBackup() {
            runOnUiThread {
                importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            }
        }

        @JavascriptInterface
        fun fetchImageAsDataUrl(imageUrl: String, callbackId: String) {
            uiScope.launch(Dispatchers.IO) {
                try {
                    val clean = imageUrl.trim()
                    if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
                        emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, '', null)")
                        return@launch
                    }
                    val req = Request.Builder()
                        .url(clean)
                        .header("User-Agent", PulseDownloader.USER_AGENT)
                        .build()
                    val dataUrl = PulseDownloader.httpClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) ""
                        else {
                            val bytes = resp.body?.bytes() ?: ByteArray(0)
                            if (bytes.isEmpty() || bytes.size > 4 * 1024 * 1024) ""
                            else {
                                val mime = resp.header("Content-Type")?.substringBefore(";")?.trim()
                                    ?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
                                "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                            }
                        }
                    }
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, ${safeJsonString(dataUrl)}, null)")
                } catch (_: Exception) {
                    emitJs("window.__pulseResolve && window.__pulseResolve(${safeJsonString(callbackId)}, '', null)")
                }
            }
        }

        @JavascriptInterface
        fun shareImageBase64(dataUrl: String, caption: String) {
            uiScope.launch(Dispatchers.IO) {
                try {
                    val b64 = dataUrl.substringAfter("base64,", dataUrl)
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val dir = File(cacheDir, "cards").apply { if (!exists()) mkdirs() }
                    val file = File(dir, "greatness-lyric-card.png")
                    FileOutputStream(file).use { it.write(bytes) }

                    val uri = FileProvider.getUriForFile(
                        this@MainActivity,
                        "${packageName}.fileprovider",
                        file
                    )
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        if (caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, caption)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    runOnUiThread {
                        startActivity(Intent.createChooser(shareIntent, "Share Lyric Card"))
                    }
                } catch (e: Exception) {
                    emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString("Could not share card: " + (e.message ?: "error"))})")
                }
            }
        }

        @JavascriptInterface
        fun playTrack(trackJson: String) {
            try {
                val obj = JSONObject(trackJson)
                startTrackPlayback(obj, forceRefresh = false, resumeMs = 0L)
            } catch (e: Exception) {
                emitJs("window.__pulseOnError && window.__pulseOnError(${safeJsonString(e.message ?: "Invalid track")})")
            }
        }

        @JavascriptInterface
        fun replayCurrent() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.seekTo(0L)
                ctrl.play()
                pushPlaybackState(snap = true)
            }
        }

        @JavascriptInterface
        fun requestCoverTheme(trackId: String, coverUrl: String) {
            extractCoverThemeAsync(trackId, coverUrl)
        }

        @JavascriptInterface
        fun togglePlay() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                togglePlaybackWithOptionalFade(ctrl)
            }
        }

        @JavascriptInterface
        fun seekTo(seconds: Double) {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.seekTo((seconds * 1000.0).toLong().coerceAtLeast(0L))
                pushPlaybackState(snap = true)
            }
        }

        @JavascriptInterface
        fun getDownloads(): String = YouTubeEngine.listDownloadsJson(this@MainActivity)

        @JavascriptInterface
        fun deleteDownload(videoId: String): Boolean {
            return YouTubeEngine.deleteDownload(this@MainActivity, videoId)
        }

        @JavascriptInterface
        fun downloadOpus(trackJson: String) {
            val obj = try {
                JSONObject(trackJson)
            } catch (e: Exception) {
                emitJs("window.__pulseOnError && window.__pulseOnError('Invalid track')")
                return
            }
            val origId = obj.optString("id").trim()
            if (origId.isBlank() || origId.startsWith("local_") || !activeDownloads.add(origId)) return

            uiScope.launch(Dispatchers.IO) {
                try {
                    val saved = YouTubeEngine.downloadCompactAudio(
                        context = this@MainActivity,
                        videoIdOrUrl = origId,
                        title = obj.optString("title", "Unknown"),
                        artist = obj.optString("artist", "YouTube"),
                        cover = obj.optString("cover", ""),
                        duration = obj.optDouble("duration", 0.0)
                    ) { pct ->
                        emitJs("window.__pulseOnDownloadProgress && window.__pulseOnDownloadProgress(${safeJsonString(origId)}, $pct)")
                    }
                    saved.put("origId", origId)
                    emitJs("window.__pulseOnDownloadDone && window.__pulseOnDownloadDone($saved)")
                } catch (e: Exception) {
                    emitJs("window.__pulseOnDownloadFailed && window.__pulseOnDownloadFailed(${safeJsonString(origId)}, ${safeJsonString(e.message ?: "Download failed")})")
                } finally {
                    activeDownloads.remove(origId)
                }
            }
        }
    }

    override fun onDestroy() {
        PlaybackSkipBus.onSkipNext = null
        PlaybackSkipBus.onSkipPrev = null
        PlaybackSkipBus.onTogglePlay = null
        activePlayJob?.cancel()
        activeThemeJob?.cancel()
        activeSearchJob?.cancel()
        activeImportJob?.cancel()
        activeArtistJob?.cancel()
        activeAlbumJob?.cancel()
        activeFadeJob?.cancel()
        activeWidgetArtJob?.cancel()
        tickerHandler.removeCallbacks(progressTicker)
        uiScope.cancel()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        try {
            webView.removeJavascriptInterface("PulseNative")
            webView.stopLoading()
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
