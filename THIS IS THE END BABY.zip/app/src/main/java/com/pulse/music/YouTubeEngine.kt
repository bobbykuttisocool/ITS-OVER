package com.pulse.music

import android.content.Context
import android.os.Environment
import android.util.Log
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.YoutubeJavaScriptPlayerManager
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.File
import java.io.FileOutputStream

object YouTubeEngine {
    private const val TAG = "PulseYTEngine"
    private const val STREAM_CACHE_TTL_MS = 25L * 60L * 1000L // 25 minutes
    private const val MAX_STREAM_CACHE = 40
    private const val MAX_AUX_CACHE = 80

    private val indexLock = Any()
    private val cacheLock = Any()
    private val searchLock = Any()

    private val V_PARAM_REGEX = Regex("[?&]v=([a-zA-Z0-9_-]{11})")
    private val SHORT_URL_REGEX = Regex("youtu\\.be/([a-zA-Z0-9_-]{11})")
    private val SHORTS_REGEX = Regex("/shorts/([a-zA-Z0-9_-]{11})")
    private val URL_EXTRACT_REGEX = Regex("https?://[^\\s\"'<>]+")
    private val LIST_PARAM_REGEX = Regex("[?&]list=([a-zA-Z0-9_-]+)")
    private val GOOGLE_SIZE_REGEX = Regex("=[ws]\\d+[^&?]*$")
    private val YTIMG_FILE_REGEX = Regex("/(default|mqdefault|hqdefault|sddefault|hq720)(_live)?\\.(jpg|webp)(\\?.*)?$", RegexOption.IGNORE_CASE)
    private val OFFLINE_EXTS = listOf("webm", "opus", "ogg", "m4a", "mp4")

    private data class CachedPlayback(
        val resolved: ResolvedPlayback,
        val cachedAtMs: Long
    )

    private data class SearchSession(
        val queryHandler: SearchQueryHandler,
        val musicOnly: Boolean,
        var nextPage: Page?,
        val seenIds: MutableSet<String>
    )

    private var activeSearchSession: SearchSession? = null

    private val streamCache = object : LinkedHashMap<String, CachedPlayback>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedPlayback>?): Boolean {
            return size > MAX_STREAM_CACHE
        }
    }

    private val relatedCache = object : LinkedHashMap<String, String>(24, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_AUX_CACHE
        }
    }

    private val sponsorCache = object : LinkedHashMap<String, String>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_AUX_CACHE
        }
    }

    private val catalogToYtIdCache = object : LinkedHashMap<String, String>(40, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > 160
        }
    }

    @Volatile
    private var lastActiveMode: String = "NewPipe v0.27.1"

    data class StreamCandidate(
        val url: String,
        val label: String,
        val ext: String,
        val bitrateKbps: Int,
        val isHls: Boolean = false
    )

    data class ResolvedPlayback(
        val candidates: List<StreamCandidate>,
        val isOffline: Boolean,
        val healed: Boolean
    )

    fun getStatusJson(): String {
        val cacheCount = synchronized(cacheLock) {
            streamCache.size + relatedCache.size + sponsorCache.size + catalogToYtIdCache.size
        }
        return JSONObject().apply {
            put("engine", "NewPipeExtractor")
            put("version", "v0.27.1")
            put("activeMode", lastActiveMode)
            put("cachedItems", cacheCount)
        }.toString()
    }

    fun resetExtractorCache(): String {
        synchronized(cacheLock) {
            streamCache.clear()
        }
        return try {
            YoutubeJavaScriptPlayerManager.clearAllCaches()
            lastActiveMode = "Cache Cleared · Fresh Auth"
            "Cleared JS & stream caches"
        } catch (e: Exception) {
            "Reset warning: ${e.message}"
        }
    }

    fun clearAllAppCaches(context: Context): String {
        val memCount = synchronized(cacheLock) {
            val n = streamCache.size + relatedCache.size + sponsorCache.size + catalogToYtIdCache.size
            streamCache.clear()
            relatedCache.clear()
            sponsorCache.clear()
            catalogToYtIdCache.clear()
            n
        }
        val themeCount = CoverThemeExtractor.clearCache()
        val catalogCount = ArtistCatalogEngine.clearCache()
        try {
            YoutubeJavaScriptPlayerManager.clearAllCaches()
        } catch (_: Exception) {
        }
        var freedBytes = 0L
        try {
            val cardsDir = File(context.cacheDir, "cards")
            if (cardsDir.exists()) {
                cardsDir.listFiles()?.forEach { f ->
                    freedBytes += f.length()
                    f.delete()
                }
            }
        } catch (_: Exception) {
        }
        lastActiveMode = "All Caches Cleared"
        val total = memCount + themeCount + catalogCount
        return "Cleared $total cached entries" + if (freedBytes > 0) " (${freedBytes / 1024} KB freed)" else ""
    }

    fun invalidateStream(videoIdOrUrl: String) {
        val id = extractVideoId(videoIdOrUrl)
        synchronized(cacheLock) { streamCache.remove(id) }
    }

    fun extractVideoId(urlOrId: String): String {
        val trimmed = urlOrId.trim()
        if (!trimmed.contains("http") && !trimmed.contains("/")) return trimmed
        V_PARAM_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
        SHORT_URL_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
        SHORTS_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { return it }
        return trimmed
    }

    fun isSquareMusicArt(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        return url.contains("googleusercontent.com", ignoreCase = true) ||
            url.contains("ggpht.com", ignoreCase = true)
    }

    fun upgradeCoverUrl(rawUrl: String?, videoId: String, targetSize: Int = 1200): String {
        val clean = rawUrl?.trim().orEmpty()
        if (clean.isNotEmpty()) {
            if (clean.startsWith("content://") || clean.startsWith("file://")) return clean
            if (clean.contains("mzstatic.com", ignoreCase = true)) {
                return clean.replace(Regex("\\d+x\\d+bb", RegexOption.IGNORE_CASE), "${targetSize}x${targetSize}bb")
            }
            if (isSquareMusicArt(clean)) {
                return if (GOOGLE_SIZE_REGEX.containsMatchIn(clean)) {
                    GOOGLE_SIZE_REGEX.replace(clean, "=w$targetSize-h$targetSize-l90-rj")
                } else if (!clean.contains("=")) {
                    "$clean=w$targetSize-h$targetSize-l90-rj"
                } else {
                    clean
                }
            }
            if (clean.contains("ytimg.com", ignoreCase = true)) {
                val upgraded = YTIMG_FILE_REGEX.replace(clean, "/maxresdefault.jpg")
                if (upgraded != clean) return upgraded
                return clean.substringBefore("?")
            }
            return clean
        }
        return if (videoId.isNotBlank() && !videoId.startsWith("local_") && !videoId.startsWith("itunes_")) {
            "https://i.ytimg.com/vi/$videoId/maxresdefault.jpg"
        } else {
            ""
        }
    }

    // Transparently resolves an iTunes catalog track (Artist/Album Page) to an ad-free YouTube Music stream ID
    fun resolveYouTubeIdForCatalogTrack(trackId: String, title: String, artist: String): String {
        if (!trackId.startsWith("itunes_")) return extractVideoId(trackId)
        synchronized(cacheLock) {
            catalogToYtIdCache[trackId]?.let { return it }
        }
        val query = "${title.trim()} ${ArtistCatalogEngine.cleanArtistQuery(artist)}".trim()
        val service = ServiceList.YouTube
        val candidates = try {
            val qh = service.searchQHFactory.fromQuery(query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), "")
            val list = SearchInfo.getInfo(service, qh).relatedItems.filterIsInstance<StreamInfoItem>()
            if (list.isNotEmpty()) list else {
                val fb = service.searchQHFactory.fromQuery("$query audio", emptyList(), "")
                SearchInfo.getInfo(service, fb).relatedItems.filterIsInstance<StreamInfoItem>()
            }
        } catch (_: Exception) {
            val fb = service.searchQHFactory.fromQuery("$query audio", emptyList(), "")
            SearchInfo.getInfo(service, fb).relatedItems.filterIsInstance<StreamInfoItem>()
        }

        val best = candidates
            .filter { it.duration in 30L..1200L }
            .firstOrNull()
            ?: candidates.firstOrNull()
            ?: throw IllegalStateException("Could not find stream for \"$title\"")

        val ytId = extractVideoId(best.url)
        if (ytId.isBlank()) throw IllegalStateException("Could not resolve YouTube ID for \"$title\"")
        synchronized(cacheLock) {
            catalogToYtIdCache[trackId] = ytId
        }
        return ytId
    }

    fun normalizePlaylistUrl(urlOrId: String): String {
        val trimmed = urlOrId.trim()
        if (trimmed.isEmpty()) throw IllegalArgumentException("Paste a YouTube playlist URL")
        LIST_PARAM_REGEX.find(trimmed)?.groupValues?.getOrNull(1)?.let { listId ->
            return "https://www.youtube.com/playlist?list=$listId"
        }
        if (!trimmed.contains("http") && !trimmed.contains("/") && trimmed.length >= 10) {
            return "https://www.youtube.com/playlist?list=$trimmed"
        }
        return trimmed.replace("music.youtube.com", "www.youtube.com")
    }

    private fun streamItemToJson(item: StreamInfoItem, source: String): JSONObject? {
        val id = extractVideoId(item.url)
        if (id.isBlank()) return null
        val rawThumb = item.thumbnails
            .maxByOrNull { it.width }?.url
            ?.takeIf { it.isNotBlank() }
        val thumb = upgradeCoverUrl(rawThumb, id, 1200)
        return JSONObject().apply {
            put("id", id)
            put("title", item.name ?: "Unknown Title")
            put("artist", item.uploaderName ?: "YouTube")
            put("duration", item.duration.coerceAtLeast(0L).toDouble())
            put("cover", thumb)
            put("source", source)
        }
    }

    fun resolveSharedInput(rawText: String): String {
        val url = URL_EXTRACT_REGEX.find(rawText)?.value?.trim() ?: rawText.trim()
        if (url.isBlank()) throw IllegalArgumentException("No YouTube link found")

        val hasList = LIST_PARAM_REGEX.containsMatchIn(url)
        val hasVideo = V_PARAM_REGEX.containsMatchIn(url) ||
            SHORT_URL_REGEX.containsMatchIn(url) ||
            SHORTS_REGEX.containsMatchIn(url)

        if (hasList && (!hasVideo || url.contains("/playlist", ignoreCase = true))) {
            val plJson = JSONObject(importPlaylist(url))
            plJson.put("type", "playlist")
            return plJson.toString()
        }

        val id = extractVideoId(url)
        if (id.length != 11) {
            throw IllegalArgumentException("Unsupported link: share a YouTube song or playlist")
        }

        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$id")
        val rawThumb = info.thumbnails
            .maxByOrNull { it.width }?.url
            ?.takeIf { it.isNotBlank() }
        val cover = upgradeCoverUrl(rawThumb, id, 1200)
        cacheRelatedFromStream(id, info)

        val track = JSONObject().apply {
            put("id", id)
            put("title", info.name ?: "Unknown Title")
            put("artist", info.uploaderName ?: "YouTube")
            put("duration", info.duration.coerceAtLeast(0L).toDouble())
            put("cover", cover)
            put("source", "shared")
        }
        return JSONObject().apply {
            put("type", "track")
            put("track", track)
        }.toString()
    }

    fun importPlaylist(urlOrId: String): String {
        val cleanUrl = normalizePlaylistUrl(urlOrId)
        val extractor = ServiceList.YouTube.getPlaylistExtractor(cleanUrl)
        extractor.fetchPage()

        val plName = try {
            extractor.name?.takeIf { it.isNotBlank() } ?: "YouTube Playlist"
        } catch (_: Exception) {
            "YouTube Playlist"
        }

        val collected = mutableListOf<StreamInfoItem>()
        var page = extractor.initialPage
        collected.addAll(page.items.filterIsInstance<StreamInfoItem>())

        var pagesFetched = 1
        while (page.hasNextPage() && collected.size < 200 && pagesFetched < 4) {
            val next: Page = page.nextPage ?: break
            try {
                page = extractor.getPage(next)
                collected.addAll(page.items.filterIsInstance<StreamInfoItem>())
                pagesFetched++
            } catch (e: Exception) {
                Log.w(TAG, "Stopped playlist pagination on page ${pagesFetched + 1}: ${e.message}")
                break
            }
        }

        val tracksArr = JSONArray()
        val seenIds = HashSet<String>()
        collected.take(200).forEach { item ->
            val obj = streamItemToJson(item, "ytplaylist")
            if (obj != null && seenIds.add(obj.getString("id"))) {
                tracksArr.put(obj)
            }
        }

        if (tracksArr.length() == 0) {
            throw IllegalStateException("No playable tracks found (check playlist is Public or Unlisted)")
        }

        return JSONObject().apply {
            put("name", plName)
            put("tracks", tracksArr)
        }.toString()
    }

    // Infinite-Scroll Paginated Search (No 25-result cap!)
    fun searchYouTubePaged(query: String, musicOnly: Boolean): String {
        val clean = query.trim()
        if (clean.isEmpty()) {
            synchronized(searchLock) { activeSearchSession = null }
            return JSONObject().apply {
                put("tracks", JSONArray())
                put("hasMore", false)
            }.toString()
        }

        val service = ServiceList.YouTube
        val filters = if (musicOnly) {
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS)
        } else {
            emptyList()
        }

        var usedMusicOnly = musicOnly
        var qh = service.searchQHFactory.fromQuery(clean, filters, "")
        var info = try {
            val primary = SearchInfo.getInfo(service, qh)
            val list = primary.relatedItems.filterIsInstance<StreamInfoItem>()
            if (list.isEmpty() && musicOnly) {
                usedMusicOnly = false
                qh = service.searchQHFactory.fromQuery(clean, emptyList(), "")
                SearchInfo.getInfo(service, qh)
            } else {
                primary
            }
        } catch (e: Exception) {
            if (musicOnly) {
                usedMusicOnly = false
                qh = service.searchQHFactory.fromQuery(clean, emptyList(), "")
                SearchInfo.getInfo(service, qh)
            } else {
                throw e
            }
        }

        val source = if (usedMusicOnly) "ytmusic" else "youtube"
        val seen = HashSet<String>()
        val out = JSONArray()
        info.relatedItems.filterIsInstance<StreamInfoItem>().forEach { item ->
            val obj = streamItemToJson(item, source)
            if (obj != null && seen.add(obj.getString("id"))) {
                out.put(obj)
            }
        }

        val next = if (info.hasNextPage()) info.nextPage else null
        synchronized(searchLock) {
            activeSearchSession = SearchSession(
                queryHandler = qh,
                musicOnly = usedMusicOnly,
                nextPage = next,
                seenIds = seen
            )
        }

        return JSONObject().apply {
            put("tracks", out)
            put("hasMore", next != null)
        }.toString()
    }

    fun searchYouTubeMore(): String {
        val session = synchronized(searchLock) { activeSearchSession }
        val pageToFetch = synchronized(searchLock) { session?.nextPage }
        if (session == null || pageToFetch == null) {
            return JSONObject().apply {
                put("tracks", JSONArray())
                put("hasMore", false)
            }.toString()
        }

        val page = SearchInfo.getMoreItems(ServiceList.YouTube, session.queryHandler, pageToFetch)
        val source = if (session.musicOnly) "ytmusic" else "youtube"
        val out = JSONArray()

        synchronized(searchLock) {
            page.items.filterIsInstance<StreamInfoItem>().forEach { item ->
                val obj = streamItemToJson(item, source)
                if (obj != null && session.seenIds.add(obj.getString("id"))) {
                    out.put(obj)
                }
            }
            session.nextPage = if (page.hasNextPage()) page.nextPage else null
        }

        val stillMore = synchronized(searchLock) { session.nextPage != null }
        return JSONObject().apply {
            put("tracks", out)
            put("hasMore", stillMore)
        }.toString()
    }

    fun searchYouTubeStateless(query: String, musicOnly: Boolean): String {
        val clean = query.trim()
        if (clean.isEmpty()) return "[]"
        val service = ServiceList.YouTube
        val filters = if (musicOnly) {
            listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS)
        } else {
            emptyList()
        }
        var usedMusicOnly = musicOnly
        val info = try {
            val qh = service.searchQHFactory.fromQuery(clean, filters, "")
            val primary = SearchInfo.getInfo(service, qh)
            val list = primary.relatedItems.filterIsInstance<StreamInfoItem>()
            if (list.isEmpty() && musicOnly) {
                usedMusicOnly = false
                SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(clean, emptyList(), ""))
            } else {
                primary
            }
        } catch (e: Exception) {
            if (musicOnly) {
                usedMusicOnly = false
                SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(clean, emptyList(), ""))
            } else {
                throw e
            }
        }
        val source = if (usedMusicOnly) "ytmusic" else "youtube"
        val seen = HashSet<String>()
        val out = JSONArray()
        info.relatedItems.filterIsInstance<StreamInfoItem>().forEach { item ->
            val obj = streamItemToJson(item, source)
            if (obj != null && seen.add(obj.getString("id"))) {
                out.put(obj)
            }
        }
        return out.toString()
    }

    fun searchYouTube(query: String, musicOnly: Boolean): String {
        return JSONObject(searchYouTubePaged(query, musicOnly)).getJSONArray("tracks").toString()
    }

    private fun cacheRelatedFromStream(videoId: String, info: StreamInfo) {
        try {
            val arr = JSONArray()
            val seen = HashSet<String>()
            seen.add(videoId)
            info.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .filter { it.duration in 45L..900L }
                .take(20)
                .forEach { item ->
                    val obj = streamItemToJson(item, "radio")
                    if (obj != null && seen.add(obj.getString("id"))) {
                        arr.put(obj)
                    }
                }
            if (arr.length() > 0) {
                synchronized(cacheLock) {
                    relatedCache[videoId] = arr.toString()
                }
            }
        } catch (_: Exception) {
        }
    }

    fun getRelatedTracksJson(videoIdOrUrl: String): String {
        val id = extractVideoId(videoIdOrUrl)
        if (id.isBlank() || id.startsWith("local_") || id.startsWith("itunes_")) return "[]"
        synchronized(cacheLock) {
            relatedCache[id]?.let { return it }
        }
        return try {
            val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$id")
            cacheRelatedFromStream(id, info)
            synchronized(cacheLock) { relatedCache[id] ?: "[]" }
        } catch (_: Exception) {
            "[]"
        }
    }

    fun fetchSponsorSegmentsJson(videoIdOrUrl: String): String {
        val id = extractVideoId(videoIdOrUrl)
        if (id.length != 11 || id.startsWith("local_") || id.startsWith("itunes_")) return "[]"
        synchronized(cacheLock) {
            sponsorCache[id]?.let { return it }
        }

        val url = "https://sponsor.ajay.app/api/skipSegments?videoID=$id&categories=%5B%22music_offtopic%22%2C%22intro%22%2C%22outro%22%2C%22sponsor%22%5D"
        val result = try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "GREATNESS-Android/14.0")
                .build()
            PulseDownloader.httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    "[]"
                } else {
                    val body = resp.body?.string().orEmpty()
                    val raw = JSONArray(body)
                    val out = JSONArray()
                    for (i in 0 until raw.length()) {
                        val obj = raw.optJSONObject(i) ?: continue
                        val seg = obj.optJSONArray("segment") ?: continue
                        if (seg.length() >= 2) {
                            val start = seg.optDouble(0, -1.0)
                            val end = seg.optDouble(1, -1.0)
                            if (start >= 0.0 && end > start + 1.0) {
                                out.put(JSONObject().apply {
                                    put("start", start)
                                    put("end", end)
                                    put("category", obj.optString("category", "music_offtopic"))
                                })
                            }
                        }
                    }
                    out.toString()
                }
            }
        } catch (_: Exception) {
            "[]"
        }

        synchronized(cacheLock) {
            sponsorCache[id] = result
        }
        return result
    }

    fun resolvePlayback(
        context: Context,
        videoIdOrUrl: String,
        forceRefresh: Boolean = false
    ): ResolvedPlayback {
        val id = extractVideoId(videoIdOrUrl)

        findOfflineFile(context, id)?.let { local ->
            lastActiveMode = "Offline · ${local.extension.uppercase()}"
            return ResolvedPlayback(
                candidates = listOf(
                    StreamCandidate(
                        url = local.toURI().toString(),
                        label = "Offline ${local.extension.uppercase()}",
                        ext = local.extension,
                        bitrateKbps = 96
                    )
                ),
                isOffline = true,
                healed = false
            )
        }

        if (forceRefresh) {
            synchronized(cacheLock) { streamCache.remove(id) }
        } else {
            val now = System.currentTimeMillis()
            synchronized(cacheLock) {
                val cached = streamCache[id]
                if (cached != null && (now - cached.cachedAtMs) < STREAM_CACHE_TTL_MS) {
                    lastActiveMode = cached.resolved.candidates.first().label
                    return cached.resolved
                }
            }
        }

        val watchUrl = "https://www.youtube.com/watch?v=$id"
        var healed = false

        val streamInfo = try {
            if (forceRefresh) {
                YoutubeJavaScriptPlayerManager.clearAllCaches()
                healed = true
            }
            StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
        } catch (firstErr: Exception) {
            Log.w(TAG, "First extraction failed, clearing JS caches and retrying: ${firstErr.message}")
            YoutubeJavaScriptPlayerManager.clearAllCaches()
            healed = true
            StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
        }

        cacheRelatedFromStream(id, streamInfo)

        val candidates = buildOrderedCandidates(streamInfo)
        if (candidates.isEmpty()) {
            throw IllegalStateException("No playable audio streams returned by YouTube")
        }

        val result = ResolvedPlayback(candidates = candidates, isOffline = false, healed = healed)
        synchronized(cacheLock) {
            streamCache[id] = CachedPlayback(result, System.currentTimeMillis())
        }
        lastActiveMode = candidates.first().label
        return result
    }

    private fun parseResolutionHeight(res: String?): Int {
        if (res.isNullOrBlank()) return Int.MAX_VALUE
        var value = 0
        var seenDigit = false
        for (ch in res) {
            if (ch in '0'..'9') {
                value = value * 10 + (ch - '0')
                seenDigit = true
            } else if (seenDigit) {
                break
            }
        }
        return if (seenDigit && value > 0) value else Int.MAX_VALUE
    }

    private fun buildOrderedCandidates(info: StreamInfo): List<StreamCandidate> {
        val list = mutableListOf<StreamCandidate>()
        val progressiveAudio = info.audioStreams
            .filter { !it.content.isNullOrBlank() && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }

        val opusStreams = progressiveAudio
            .filter { it.format == MediaFormat.WEBMA_OPUS || it.format == MediaFormat.OPUS }
            .sortedBy { kotlin.math.abs((it.averageBitrate.takeIf { b -> b > 0 } ?: 128) - 128) }
        opusStreams.forEach { s ->
            val br = s.averageBitrate.takeIf { it > 0 } ?: 128
            list.add(StreamCandidate(s.content, "Opus ${br}k", "webm", br))
        }

        val m4aStreams = progressiveAudio
            .filter { it.format == MediaFormat.M4A }
            .sortedByDescending { it.averageBitrate }
        m4aStreams.forEach { s ->
            val br = s.averageBitrate.takeIf { it > 0 } ?: 128
            list.add(StreamCandidate(s.content, "M4A ${br}k", "m4a", br))
        }

        progressiveAudio
            .filter { s -> list.none { it.url == s.content } }
            .sortedByDescending { it.averageBitrate }
            .forEach { s ->
                val br = s.averageBitrate.takeIf { it > 0 } ?: 96
                val ext = s.format?.suffix ?: "webm"
                list.add(StreamCandidate(s.content, "${ext.uppercase()} ${br}k", ext, br))
            }

        val hlsUrl = info.hlsUrl
        if (!hlsUrl.isNullOrBlank()) {
            list.add(StreamCandidate(hlsUrl, "HLS Adaptive", "m3u8", 128, isHls = true))
        }

        info.videoStreams
            .filter { !it.content.isNullOrBlank() && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .sortedBy { parseResolutionHeight(it.resolution) }
            .firstOrNull()
            ?.let { mux ->
                list.add(StreamCandidate(mux.content, "Fallback Audio", "mp4", 128))
            }

        return list.distinctBy { it.url }
    }

    fun getOfflineDir(context: Context): File {
        val base = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
        val dir = File(base, "PulseOpus")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getIndexFile(context: Context): File = File(getOfflineDir(context), "library.json")

    fun findOfflineFile(context: Context, videoId: String): File? {
        if (videoId.startsWith("local_")) return null
        if (videoId.startsWith("itunes_")) return findOfflineFileByOrigId(context, videoId)
        val dir = getOfflineDir(context)
        for (ext in OFFLINE_EXTS) {
            val f = File(dir, "$videoId.$ext")
            if (f.exists() && f.length() > 1024L) return f
        }
        return null
    }

    fun findOfflineFileByOrigId(context: Context, origId: String): File? {
        return synchronized(indexLock) {
            val indexFile = getIndexFile(context)
            if (!indexFile.exists()) return@synchronized null
            try {
                val arr = JSONArray(indexFile.readText())
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    if (item.optString("origId") == origId || item.optString("id") == origId) {
                        val f = File(item.optString("filePath"))
                        if (f.exists() && f.length() > 1024L) return@synchronized f
                    }
                }
                null
            } catch (_: Exception) {
                null
            }
        }
    }

    fun listDownloadsJson(context: Context): String {
        return synchronized(indexLock) {
            val indexFile = getIndexFile(context)
            if (!indexFile.exists()) return@synchronized "[]"
            try {
                val raw = JSONArray(indexFile.readText())
                val valid = JSONArray()
                var pruned = false
                for (i in 0 until raw.length()) {
                    val obj = raw.getJSONObject(i)
                    val f = File(obj.optString("filePath"))
                    if (f.exists() && f.length() > 1024L) {
                        obj.put("sizeKb", f.length() / 1024L)
                        valid.put(obj)
                    } else {
                        pruned = true
                    }
                }
                if (pruned) {
                    try { indexFile.writeText(valid.toString()) } catch (_: Exception) {}
                }
                valid.toString()
            } catch (_: Exception) {
                "[]"
            }
        }
    }

    fun deleteDownload(context: Context, videoId: String): Boolean {
        return synchronized(indexLock) {
            val id = extractVideoId(videoId)
            val dir = getOfflineDir(context)
            var deleted = false
            for (ext in OFFLINE_EXTS) {
                val f = File(dir, "$id.$ext")
                if (f.exists() && f.delete()) deleted = true
            }
            val indexFile = getIndexFile(context)
            if (indexFile.exists()) {
                try {
                    val arr = JSONArray(indexFile.readText())
                    val updated = JSONArray()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val match = item.optString("id") == id || item.optString("origId") == videoId
                        if (match) {
                            val fp = item.optString("filePath")
                            if (fp.isNotBlank()) {
                                val f = File(fp)
                                if (f.exists() && f.delete()) deleted = true
                            }
                        } else {
                            updated.put(item)
                        }
                    }
                    indexFile.writeText(updated.toString())
                } catch (_: Exception) {
                }
            }
            deleted
        }
    }

    fun downloadCompactAudio(
        context: Context,
        videoIdOrUrl: String,
        title: String,
        artist: String,
        cover: String,
        duration: Double,
        onProgress: (Int) -> Unit
    ): JSONObject {
        val id = resolveYouTubeIdForCatalogTrack(videoIdOrUrl, title, artist)
        val resolved = resolvePlayback(context, id, forceRefresh = false)

        val target = resolved.candidates
            .filter { !it.isHls && it.url.startsWith("http") }
            .sortedWith(
                compareBy<StreamCandidate>(
                    { if (it.ext == "webm" || it.ext == "opus") 0 else 1 },
                    { kotlin.math.abs(it.bitrateKbps - 96) }
                )
            )
            .firstOrNull()
            ?: throw IllegalStateException("No direct downloadable audio stream available for this track")

        val dir = getOfflineDir(context)
        val tmpFile = File(dir, "$id.${target.ext}.part")
        val finalFile = File(dir, "$id.${target.ext}")

        val request = Request.Builder()
            .url(target.url)
            .header("User-Agent", PulseDownloader.USER_AGENT)
            .build()

        try {
            PulseDownloader.httpClient.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    if (resp.code == 403 || resp.code == 410) invalidateStream(id)
                    throw IllegalStateException("Download HTTP ${resp.code}")
                }
                val body = resp.body ?: throw IllegalStateException("Empty audio response")
                val totalBytes = body.contentLength()
                var copied = 0L
                var lastReported = -1

                body.byteStream().use { input ->
                    FileOutputStream(tmpFile).use { output ->
                        val buffer = ByteArray(32 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            copied += read
                            if (totalBytes > 0L) {
                                val pct = ((copied * 100L) / totalBytes).toInt().coerceIn(0, 99)
                                if (pct >= lastReported + 3) {
                                    lastReported = pct
                                    onProgress(pct)
                                }
                            }
                        }
                        output.flush()
                    }
                }
            }
        } catch (e: Exception) {
            if (tmpFile.exists()) tmpFile.delete()
            throw e
        }

        if (finalFile.exists()) finalFile.delete()
        if (!tmpFile.renameTo(finalFile)) {
            tmpFile.copyTo(finalFile, overwrite = true)
            tmpFile.delete()
        }
        onProgress(100)

        val codecLabel = if (target.ext == "webm" || target.ext == "opus") {
            "OPUS ${target.bitrateKbps}k"
        } else {
            "${target.ext.uppercase()} ${target.bitrateKbps}k"
        }

        val entry = JSONObject().apply {
            put("id", id)
            if (videoIdOrUrl.startsWith("itunes_")) {
                put("origId", videoIdOrUrl)
            }
            put("title", title)
            put("artist", artist)
            put("cover", cover)
            put("duration", duration)
            put("codec", codecLabel)
            put("sizeKb", finalFile.length() / 1024L)
            put("filePath", finalFile.absolutePath)
            put("source", "offline")
        }

        saveToIndex(context, entry)
        return entry
    }

    private fun saveToIndex(context: Context, entry: JSONObject) {
        synchronized(indexLock) {
            val indexFile = getIndexFile(context)
            val arr = if (indexFile.exists()) {
                try { JSONArray(indexFile.readText()) } catch (_: Exception) { JSONArray() }
            } else JSONArray()

            val updated = JSONArray()
            val id = entry.getString("id")
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                if (item.optString("id") != id) updated.put(item)
            }
            updated.put(entry)
            indexFile.writeText(updated.toString())
        }
    }
}
