package com.pulse.music

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

class GreatnessWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_PLAY_PAUSE = "com.pulse.music.WIDGET_PLAY_PAUSE"
        const val ACTION_NEXT = "com.pulse.music.WIDGET_NEXT"
        const val ACTION_ROULETTE = "com.pulse.music.WIDGET_ROULETTE"
        const val EXTRA_SPIN_ROULETTE = "extra_spin_roulette"

        @Volatile
        var lastTitle: String = "GREATNESS"
        @Volatile
        var lastArtist: String = "Tap Spin for Liked Roulette"
        @Volatile
        var lastPlaying: Boolean = false
        @Volatile
        var lastBitmap: Bitmap? = null

        fun updateAllWidgets(
            context: Context,
            title: String = lastTitle,
            artist: String = lastArtist,
            isPlaying: Boolean = lastPlaying,
            artwork: Bitmap? = lastBitmap
        ) {
            lastTitle = title
            lastArtist = artist
            lastPlaying = isPlaying
            if (artwork != null) lastBitmap = artwork

            try {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(
                    ComponentName(context, GreatnessWidgetProvider::class.java)
                )
                if (ids.isEmpty()) return
                val views = buildViews(context)
                for (id in ids) {
                    manager.updateAppWidget(id, views)
                }
            } catch (_: Exception) {
            }
        }

        private fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_greatness)
            views.setTextViewText(R.id.widgetTitle, lastTitle)
            views.setTextViewText(R.id.widgetArtist, lastArtist)
            views.setTextViewText(R.id.widgetPlayBtn, if (lastPlaying) "❚❚" else "▶")
            val bmp = lastBitmap
            if (bmp != null && !bmp.isRecycled) {
                views.setImageViewBitmap(R.id.widgetArt, bmp)
            } else {
                views.setImageViewResource(R.id.widgetArt, R.mipmap.ic_launcher_round)
            }

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

            val openIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            views.setOnClickPendingIntent(
                R.id.widgetRoot,
                PendingIntent.getActivity(context, 100, openIntent, flags)
            )

            val playIntent = Intent(context, GreatnessWidgetProvider::class.java).apply {
                action = ACTION_PLAY_PAUSE
            }
            views.setOnClickPendingIntent(
                R.id.widgetPlayBtn,
                PendingIntent.getBroadcast(context, 101, playIntent, flags)
            )

            val nextIntent = Intent(context, GreatnessWidgetProvider::class.java).apply {
                action = ACTION_NEXT
            }
            views.setOnClickPendingIntent(
                R.id.widgetNextBtn,
                PendingIntent.getBroadcast(context, 102, nextIntent, flags)
            )

            val rouletteIntent = Intent(context, MainActivity::class.java).apply {
                action = ACTION_ROULETTE
                putExtra(EXTRA_SPIN_ROULETTE, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            views.setOnClickPendingIntent(
                R.id.widgetRouletteBtn,
                PendingIntent.getActivity(context, 103, rouletteIntent, flags)
            )

            return views
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val views = buildViews(context)
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, views)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PLAY_PAUSE -> {
                val cb = PlaybackSkipBus.onTogglePlay
                if (cb != null) {
                    cb.invoke()
                } else {
                    val launch = Intent(context, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    context.startActivity(launch)
                }
            }
            ACTION_NEXT -> {
                val cb = PlaybackSkipBus.onSkipNext
                if (cb != null) {
                    cb.invoke()
                } else {
                    val launch = Intent(context, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    }
                    context.startActivity(launch)
                }
            }
            ACTION_ROULETTE -> {
                val launch = Intent(context, MainActivity::class.java).apply {
                    putExtra(EXTRA_SPIN_ROULETTE, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                context.startActivity(launch)
            }
        }
    }
}
