-keep class com.pulse.music.** { *; }
-keepclassmembers class com.pulse.music.MainActivity$PulseJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.tools.**
